# Конфигурация базы данных
DATABASE_CONFIG = {
    'host': 'localhost',
    'user': 'wifi_user',
    'password': 'secure_password_123',  # Замени на свой пароль
    'database': 'wifi_ids',
    'charset': 'utf8mb4'
}

# Настройки сервера
SERVER_CONFIG = {
    'host': '0.0.0.0',
    'port': 8080,
    'debug': True
}

# Настройки безопасности
SECURITY_CONFIG = {
    'allowed_origins': ['http://localhost:3000', 'http://your-server-ip'],
    'rate_limit': '100/hour'
}
