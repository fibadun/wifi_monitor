#!/usr/bin/env python3
"""
WiFi IDS Server - Центральный сервер для сбора и отображения данных
"""
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from datetime import datetime
import json
import pymysql
import pymysql.cursors
from config import DATABASE_CONFIG

app = Flask(__name__)
CORS(app)  # Разрешаем запросы с других доменов

# Конфигурация БД из отдельного файла
db_config = DATABASE_CONFIG

def get_db_connection():
    """Создает подключение к базе данных"""
    return pymysql.connect(
        host=db_config['host'],
        user=db_config['user'],
        password=db_config['password'],
        database=db_config['database'],
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )

@app.route('/')
def index():
    """Главная страница с дашбордом"""
    return render_template('index.html')

@app.route('/api/v1/health', methods=['GET'])
def health_check():
    """Проверка работоспособности сервера"""
    return jsonify({
        'status': 'ok',
        'timestamp': datetime.now().isoformat(),
        'service': 'WiFi IDS Server'
    }), 200

@app.route('/api/v1/logs', methods=['POST'])
def receive_logs():
    """
    Принимает данные от ESP8266
    Пример JSON:
    {
        "device_id": "esp8266-001",
        "timestamp": 1234567890,
        "network_count": 5,
        "threat_count": 1,
        "networks": [...],
        "threats": [...]
    }
    """
    try:
        data = request.json
        
        if not data:
            return jsonify({'error': 'No JSON data received'}), 400
        
        # Подключаемся к БД
        connection = get_db_connection()
        
        try:
            with connection.cursor() as cursor:
                # Сохраняем общий сканирования
                sql_scan = """
                INSERT INTO scans (device_id, timestamp, network_count, threat_count, raw_data)
                VALUES (%s, %s, %s, %s, %s)
                """
                cursor.execute(sql_scan, (
                    data.get('device_id'),
                    datetime.fromtimestamp(data.get('timestamp', 0)),
                    data.get('network_count', 0),
                    data.get('threat_count', 0),
                    json.dumps(data)
                ))
                scan_id = cursor.lastrowid
                
                # Сохраняем сети
                for network in data.get('networks', []):
                    sql_network = """
                    INSERT INTO networks (scan_id, ssid, bssid, channel, rssi, encryption, is_hidden)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """
                    cursor.execute(sql_network, (
                        scan_id,
                        network.get('ssid'),
                        network.get('bssid'),
                        network.get('channel'),
                        network.get('rssi'),
                        network.get('encryption'),
                        network.get('is_hidden', False)
                    ))
                
                # Сохраняем угрозы
                for threat in data.get('threats', []):
                    sql_threat = """
                    INSERT INTO threats (scan_id, type, severity, description, target_ssid, target_bssid)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """
                    cursor.execute(sql_threat, (
                        scan_id,
                        threat.get('type'),
                        threat.get('severity'),
                        threat.get('description'),
                        threat.get('target_ssid'),
                        threat.get('target_bssid')
                    ))
                
                connection.commit()
                
                return jsonify({
                    'status': 'success',
                    'scan_id': scan_id,
                    'message': f'Logged {len(data.get("networks", []))} networks and {len(data.get("threats", []))} threats'
                }), 201
                
        finally:
            connection.close()
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/statistics', methods=['GET'])
def get_statistics():
    """Возвращает статистику для дашборда"""
    try:
        connection = get_db_connection()
        
        with connection.cursor() as cursor:
            # Общая статистика
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_scans,
                    SUM(network_count) as total_networks,
                    SUM(threat_count) as total_threats,
                    MAX(timestamp) as last_scan
                FROM scans
                WHERE timestamp > DATE_SUB(NOW(), INTERVAL 24 HOUR)
            """)
            stats = cursor.fetchone()
            
            # Угрозы по типам
            cursor.execute("""
                SELECT type, COUNT(*) as count
                FROM threats
                WHERE created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
                GROUP BY type
                ORDER BY count DESC
            """)
            threats_by_type = cursor.fetchall()
            
            # Последние 10 угроз
            cursor.execute("""
                SELECT t.type, t.severity, t.description, t.target_ssid, s.timestamp
                FROM threats t
                JOIN scans s ON t.scan_id = s.id
                ORDER BY t.created_at DESC
                LIMIT 10
            """)
            recent_threats = cursor.fetchall()
            
            # Сети по часам (для графика)
            cursor.execute("""
                SELECT 
                    HOUR(timestamp) as hour,
                    AVG(network_count) as avg_networks
                FROM scans
                WHERE timestamp > DATE_SUB(NOW(), INTERVAL 24 HOUR)
                GROUP BY HOUR(timestamp)
                ORDER BY hour
            """)
            networks_by_hour = cursor.fetchall()
            
        connection.close()
        
        return jsonify({
            'stats': stats,
            'threats_by_type': threats_by_type,
            'recent_threats': recent_threats,
            'networks_by_hour': networks_by_hour,
            'timestamp': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/devices', methods=['GET'])
def get_devices():
    """Возвращает список устройств"""
    try:
        connection = get_db_connection()
        
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT 
                    device_id,
                    COUNT(*) as scan_count,
                    MAX(timestamp) as last_seen,
                    SUM(threat_count) as total_threats
                FROM scans
                GROUP BY device_id
                ORDER BY last_seen DESC
            """)
            devices = cursor.fetchall()
            
        connection.close()
        
        return jsonify({'devices': devices}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
